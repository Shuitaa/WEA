
-- --------------------------------------------------------

--
-- Structure de la table `wea_mot`
--

CREATE TABLE `wea_mot` (
  `id_mot` int(10) NOT NULL,
  `lettre_id` int(2) NOT NULL,
  `mot` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `mot_ref` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `wea_mot`
--

INSERT INTO `wea_mot` (`id_mot`, `lettre_id`, `mot`, `description`, `mot_ref`) VALUES
(1, 3, 'citadelle', '', ''),
(2, 6, 'faubourgs', '', '');
