
--
-- Index pour les tables déchargées
--

--
-- Index pour la table `wea_contact`
--
ALTER TABLE `wea_contact`
  ADD PRIMARY KEY (`id_contact`);

--
-- Index pour la table `wea_definition`
--
ALTER TABLE `wea_definition`
  ADD PRIMARY KEY (`id_definition`);

--
-- Index pour la table `wea_image`
--
ALTER TABLE `wea_image`
  ADD PRIMARY KEY (`id_image`);

--
-- Index pour la table `wea_lettre`
--
ALTER TABLE `wea_lettre`
  ADD PRIMARY KEY (`id_lettre`);

--
-- Index pour la table `wea_mot`
--
ALTER TABLE `wea_mot`
  ADD PRIMARY KEY (`id_mot`);

--
-- Index pour la table `wea_news`
--
ALTER TABLE `wea_news`
  ADD PRIMARY KEY (`id_news`);

--
-- Index pour la table `wea_parametre`
--
ALTER TABLE `wea_parametre`
  ADD PRIMARY KEY (`id_param`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `wea_contact`
--
ALTER TABLE `wea_contact`
  MODIFY `id_contact` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `wea_definition`
--
ALTER TABLE `wea_definition`
  MODIFY `id_definition` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `wea_image`
--
ALTER TABLE `wea_image`
  MODIFY `id_image` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `wea_lettre`
--
ALTER TABLE `wea_lettre`
  MODIFY `id_lettre` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `wea_mot`
--
ALTER TABLE `wea_mot`
  MODIFY `id_mot` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `wea_news`
--
ALTER TABLE `wea_news`
  MODIFY `id_news` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `wea_parametre`
--
ALTER TABLE `wea_parametre`
  MODIFY `id_param` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
