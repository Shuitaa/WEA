
-- --------------------------------------------------------

--
-- Structure de la table `wea_lettre`
--

CREATE TABLE `wea_lettre` (
  `id_lettre` int(2) NOT NULL,
  `lettre` varchar(1) NOT NULL,
  `description_lettre` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `wea_lettre`
--

INSERT INTO `wea_lettre` (`id_lettre`, `lettre`, `description_lettre`) VALUES
(1, 'a', 'A comme appartement'),
(2, 'b', 'B comme boulevard'),
(3, 'c', 'C comme cité'),
(4, 'd', 'D comme dame'),
(5, 'e', 'E comme enceinte'),
(6, 'f', 'F comme faubourg');
