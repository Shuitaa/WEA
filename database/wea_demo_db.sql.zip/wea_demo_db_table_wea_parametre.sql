
-- --------------------------------------------------------

--
-- Structure de la table `wea_parametre`
--

CREATE TABLE `wea_parametre` (
  `id_param` int(10) NOT NULL,
  `titre_site` varchar(255) DEFAULT NULL,
  `titre_home_presentation` varchar(255) DEFAULT NULL,
  `home_presentation` text DEFAULT NULL,
  `url_logo` varchar(255) DEFAULT NULL,
  `plan_site` varchar(255) DEFAULT NULL,
  `titre_mentions_legales` varchar(255) DEFAULT NULL,
  `texte_mentions_legales` text DEFAULT NULL,
  `url_compte_twitter` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `wea_parametre`
--

INSERT INTO `wea_parametre` (`id_param`, `titre_site`, `titre_home_presentation`, `home_presentation`, `url_logo`, `plan_site`, `titre_mentions_legales`, `texte_mentions_legales`, `url_compte_twitter`) VALUES
(1, 'L\'encyclopédie de la Cité des dames', 'Présentation de l’encyclopédie de la Cité des dames', '<p>Ce site est conçu comme une démonstration du système de gestion de contenus <a href=\"https://github.com/Shuitaa/WEA\">WEA</a> de Pierre Averty, dans le cadre d’un stage pour le projet <a href=\"http://citedesdames.hypotheses.org\"><i>Cité des dames : créatrices dans la cité</i></a> de l’université Gustave Eiffel.</p>', NULL, NULL, 'Mentions légales du projet WEA', '<ul>\r\n<li>Développement du CMS : Pierre Averty</li>\r\n<li>Contenu (textes et images) : Philippe Gambette</li>\r\n</ul>', NULL);
