
-- --------------------------------------------------------

--
-- Structure de la table `wea_image`
--

CREATE TABLE `wea_image` (
  `id_image` int(10) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `alt` varchar(255) NOT NULL,
  `url_image` varchar(255) NOT NULL,
  `accueil` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `wea_image`
--

INSERT INTO `wea_image` (`id_image`, `nom`, `alt`, `url_image`, `accueil`) VALUES
(1, 'Manuscrit Français 1177 de la Bibliothèque nationale de France - La Cité des dames, Christine de Pizan', 'Manuscrit Français 1177 de la Bibliothèque nationale de France - https://gallica.bnf.fr/ark:/12148/btv1b84497026/f10.item', 'http://citedesdames.hypotheses.org/files/2020/07/btv1b84497026-f10-scaled.jpg', 1),
(2, 'Manuscrit Français 607 de la Bibliothèque nationale de France - La Cité des dames, Christine de Pizan', 'Manuscrit Français 607 de la Bibliothèque nationale de France - https://gallica.bnf.fr/ark:/12148/btv1b6000102v/f11.item', 'http://citedesdames.hypotheses.org/files/2020/07/btv1b6000102v-f11.jpg', 1),
(3, 'Manuscrit Français 607 de la Bibliothèque nationale de France - La Cité des dames, Christine de Pizan', 'Manuscrit Français 607 de la Bibliothèque nationale de France - https://gallica.bnf.fr/ark:/12148/btv1b6000102v-f70/f70.item', 'http://citedesdames.hypotheses.org/files/2020/07/btv1b6000102v-f70.jpg', 1),
(4, 'Manuscrit Français 609 de la Bibliothèque nationale de France - La Cité des dames, Christine de Pizan', 'Manuscrit Français 609 de la Bibliothèque nationale de France - https://gallica.bnf.fr/ark:/12148/btv1b8448962v/f16.item', 'http://citedesdames.hypotheses.org/files/2020/07/btv1b8448962v-f16-scaled.jpg', 1),
(5, 'Manuscrit Français 1177 de la Bibliothèque nationale de France - La Cité des dames, Christine de Pizan', 'Manuscrit Français 609 de la Bibliothèque nationale de France - https://gallica.bnf.fr/ark:/12148/btv1b8448962v/f268.item', 'http://citedesdames.hypotheses.org/files/2020/07/btv1b8448962v-f268.jpg', 1);
