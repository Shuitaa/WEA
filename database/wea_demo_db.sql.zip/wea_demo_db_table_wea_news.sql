
-- --------------------------------------------------------

--
-- Structure de la table `wea_news`
--

CREATE TABLE `wea_news` (
  `id_news` int(10) NOT NULL,
  `image_id` int(10) DEFAULT NULL,
  `titre_news` varchar(255) NOT NULL,
  `texte_news` text NOT NULL,
  `date_news` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `wea_news`
--

INSERT INTO `wea_news` (`id_news`, `image_id`, `titre_news`, `texte_news`, `date_news`) VALUES
(1, NULL, 'Début du développement de WEA', '<p>Pierre Averty a commencé aujourd’hui son stage au Laboratoire d’informatique Gaspard Monge, pour le projet <a href=\"http://citedesdames.hypotheses.org\"><i>Cité des dames : créatrices dans la cité</i></a> de l’université Gustave Eiffel.</p>\n<p>Ce stage vise à développer un système de gestion de contenu, appelé WEA pour « Web Encyclopedia Application », qui vise à proposer une encyclopédie en ligne dont le contenu est chargé à partir d’un fichier Word structuré. Développé sous licence libre AGPL, dans les langages HTML, CSS, PHP, SQL et Javascript, il est conçu d’après une idée de la créatrice de l’<a href=\"https://www.encyclopediedesfemmes.com/\">Encyclopédie des Femmes</a>, qui sera migré sur le système WEA à l’issue du développement de ce dernier.</p>', '2020-06-30 08:00:00'),
(2, 2, 'Quelques premières images', '<p>Des images tirées de plusieurs manuscrits de <i>La Cité des dames</i> de Christine de Pizan conservés à la bibliothèque nationale de France et mis à disposition sur Gallica ont été ajoutées à ce site.</p>', '2020-07-02 20:00:00'),
(3, NULL, 'Quelques premiers mots', '<p>Des citations sur les mots « cité » et « faubourgs », tirées des <i>Mémoires</i> de Marguerite de Valois, dans l’<a href=\"http://www.elianeviennot.fr/Marguerite/MgV-Memoires.html\">édition en ligne d’Éliane Viennot</a>, ont été ajoutées sur ce site.</p>', '2020-07-03 04:40:02');
