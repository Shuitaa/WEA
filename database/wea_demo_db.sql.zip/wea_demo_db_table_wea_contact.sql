
-- --------------------------------------------------------

--
-- Structure de la table `wea_contact`
--

CREATE TABLE `wea_contact` (
  `id_contact` int(10) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
