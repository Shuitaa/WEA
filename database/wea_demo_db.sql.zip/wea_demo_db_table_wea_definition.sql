
-- --------------------------------------------------------

--
-- Structure de la table `wea_definition`
--

CREATE TABLE `wea_definition` (
  `id_definition` int(10) NOT NULL,
  `mot_id` int(10) NOT NULL,
  `titre` varchar(255) NOT NULL,
  `texte` text NOT NULL,
  `source` varchar(255) NOT NULL,
  `commentaire` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `wea_definition`
--

INSERT INTO `wea_definition` (`id_definition`, `mot_id`, `titre`, `texte`, `source`, `commentaire`) VALUES
(1, 1, 'citadelle', '« Ce que je reconnus en cette ville [digne] d’estime et de remarque fut la citadelle, des plus belles et des mieux achevées de la chrétienté »', '<i>Mémoires de Marguerite de Valois</i> (1594-?), <a href=\"http://www.elianeviennot.fr/Marguerite/MgV-Memoires.html\">http://www.elianeviennot.fr/Marguerite/MgV-Memoires.html</a>', 'À propos de Cambrai'),
(2, 2, 'faubourgs', '« Soudain qu’ils nous voient approcher les faubourgs avec une troupe grande comme était la mienne, les voilà alarmés. Ils quittent les verres pour courir aux armes, et tout en tumulte, au lieu de nous ouvrir, ils ferment la barrière. »', '<i>Mémoires de Marguerite de Valois</i> (1594-?), <a href=\"http://www.elianeviennot.fr/Marguerite/MgV-Memoires.html\">http://www.elianeviennot.fr/Marguerite/MgV-Memoires.html</a>', 'À propos de Dinant');
