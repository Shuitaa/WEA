<?php
    $db = new PDO ("mysql:host=sqletud.u-pem.fr;dbname=paverty_db", "paverty", "DinoLacambra", array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
?>